bootGame = {
	create: function() {
		game.physics.startSystem(Phaser.Physics.ARCADE);
		keyboard = game.input.keyboard.createCursorKeys(); 
		game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
		game.scale.pageAlignHorizontally = true;
		

		game.state.start("preloadGame");
	},
}