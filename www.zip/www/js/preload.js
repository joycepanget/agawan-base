	preloadGame = {
	preload: function(){

		game.load.image("bg","img/background.png");
		game.load.image("bg1","img/frontpage.png");
		game.load.audio("bgmusic","audio/bgmusic11.mp3");
		game.load.audio("menuAudio","audio/menu.mp3");
		game.load.audio("win","audio/win.mp3");
		game.load.audio("lose","audio/lose.mp3");
		game.load.image("black","img/blackteam.png");
		game.load.image("yellow","img/yellowteam.png");
		game.load.image("boatplayer","img/boat.png");
		game.load.image("Dyellow","img/Dboat.png");
		game.load.image("Denemy","img/Denemy.png");
		game.load.image("Aenemy","img/Aenemy.png");
		game.load.image("up","img/up.png");
		game.load.image("down","img/down.png");
		game.load.image("right","img/right.png");
		game.load.image("left","img/left.png");
		game.load.image("pause","img/pause.png");
		game.load.image("restart","img/restart.png");
		game.load.image("play","img/play.png");
		game.load.spritesheet("sabog","img/sabog.png",66,59);
	},
	create: function(){
		game.state.start("menuGame");
	},

}