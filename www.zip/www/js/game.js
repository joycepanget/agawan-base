var  w = 1200, h = 600;
	
	var bgAudio, yellow, black, boatplayer, bg, bg1, Dyellow1, Dyellow2;
	var killPlayer;

	var left=false;
	var right=false;
	var up=false;
	var down=false;

var game = new Phaser.Game(w, h, Phaser.CANVAS, '');

game.state.add("bootGame",bootGame);
game.state.add("preloadGame",preloadGame);
game.state.add("menuGame",menuGame);
game.state.add("playGame",playGame);
/*game.state.add("winGame",winGame);
game.state.add("loseGame",loseGame);*/

game.state.start("bootGame");	