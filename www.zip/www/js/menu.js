menuGame = {
	create: function() {
		bg1 = game.add.image(0,0,"bg1")
		bg1.scale.x = 1.5;
		playButton = game.add.button(w/2-60,h/2, 'play',this.play, this,1,0);
    	playButton.scale.x = 0.6;
    	playButton.scale.y = 0.6;

    	menuAudio = game.add.audio("menuAudio");
    	menuAudio.loop = true;
    	menuAudio.play();
	},
	update: function(){
	},
	play: function(){
    	game.state.start("playGame");
		}
}
