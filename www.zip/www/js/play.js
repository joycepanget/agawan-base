playGame = {
	create: function(){
		bg = game.add.tileSprite(0,
			game.height - game.cache.getImage("bg").height,800,800,'bg');
		bg.scale.x = 1.5;
		black = game.add.sprite(12,12, 'black');
		black.scale.x = 0.2; black.scale.y = 0.2;
		yellow = game.add.sprite(1050,490,'yellow');
		yellow.scale.x = 0.4; yellow.scale.y = 0.4;
		boatplayer = game.add.sprite(1050,500,'boatplayer');
		boatplayer.scale.x = 0.2; boatplayer.scale.y = 0.2;	
		Dyellow1 = game.add.sprite(950,550,'Dyellow');
		Dyellow1.scale.x = 0.2; Dyellow1.scale.y = 0.2;
		Dyellow2 = game.add.sprite(1100,400,'Dyellow');
		Dyellow2.scale.x = 0.2; Dyellow2.scale.y = 0.2;	

		Denemy1 = game.add.sprite(150,20,'Denemy');
		Denemy1.scale.x = 0.2; Denemy1.scale.y = 0.2;
		Denemy2 = game.add.sprite(10,150,'Denemy');
		Denemy2.scale.x = 0.2; Denemy2.scale.y = 0.2;	
		Aenemy = game.add.sprite(Math.random()*w-100,Math.random()*h-100,'Aenemy');
		Aenemy.scale.x = 0.2; Aenemy.scale.y = 0.2;
		menuAudio.destroy();
		bgAudio = game.add.audio("bgmusic");
    	bgAudio.loop = true;
    	bgAudio.play();

    	game.physics.arcade.enable(boatplayer);
    	game.physics.arcade.enable(Dyellow1);
    	game.physics.arcade.enable(Dyellow2);
    	game.physics.arcade.enable(Denemy1);
    	game.physics.arcade.enable(Denemy2);
    	game.physics.arcade.enable(Aenemy);
    	game.physics.arcade.enable(black);
    	game.physics.arcade.enable(yellow);
    	black.body.immovable = true;
    	yellow.body.immovable = true;
    	boatplayer.body.collideWorldBounds = true;
    	Dyellow1.body.collideWorldBounds = true;
    	Dyellow2.body.collideWorldBounds = true;
    	Denemy1.body.collideWorldBounds = true;
    	Denemy2.body.collideWorldBounds = true;
    	Aenemy.body.collideWorldBounds = true;
    	boatplayer.anchor.setTo(0.5);
    	up = game.add.button(90,420, 'up', null, this, 0, 1, 0, 1);
		up.scale.x = 0.2; up.scale.y = 0.2;
		up.events.onInputOver.add(function(){up=true;});
    	up.events.onInputOut.add(function(){up=false;});
    	up.events.onInputDown.add(function(){up=true;});
    	up.events.onInputUp.add(function(){up=false;});
		down = game.add.button(90,540, 'down', null, this, 0, 1, 0, 1);
		down.scale.x = 0.2; down.scale.y = 0.2;
		down.events.onInputOver.add(function(){down=true;});
    	down.events.onInputOut.add(function(){down=false;});
    	down.events.onInputDown.add(function(){down=true;});
    	down.events.onInputUp.add(function(){down=false;});
		right = game.add.button(160,480, 'right', null, this, 0, 1, 0, 1);
		right.scale.x = 0.2; right.scale.y = 0.2;
		right.events.onInputOver.add(function(){right=true;});
    	right.events.onInputOut.add(function(){right=false;});
    	right.events.onInputDown.add(function(){right=true;});
    	right.events.onInputUp.add(function(){right=false;});
		left = game.add.button(20,480, 'left', null, this, 0, 1, 0, 1);
		left.scale.x = 0.2; left.scale.y = 0.2;left
    	left.events.onInputOver.add(function(){left=true;});
    	left.events.onInputOut.add(function(){left=false;});
    	left.events.onInputDown.add(function(){left=true;});
    	left.events.onInputUp.add(function(){left=false;});	
    		
    			pauseButton = game.add.button(1135,5, 'pause',this.pause, this,1,0);
    	pauseButton.scale.x = 0.3;
    	pauseButton.scale.y = 0.3;
    	restartButton = game.add.button(1070,5, 'restart',this.restart, this,1,0);
    	restartButton.scale.x = 0.3;
    	restartButton.scale.y = 0.3;
    	  pauseButton.fixedToCamera = true; 
           restartButton.fixedToCamera = true;
            sabog = game.add.sprite(850,650,"sabog");
           
winAudio = game.add.audio("win");
loseAudio = game.add.audio("lose");
            gameOverText = game.add.text((w/2)-90,250,"",{fill:'white',align:'center'});
	},
	update: function() {
		game.physics.arcade.collide(boatplayer,yellow);
		
		game.physics.arcade.collide(Aenemy,boatplayer);
		game.physics.arcade.collide(Denemy1,Denemy2);
		game.physics.arcade.collide(Dyellow1,Dyellow2);
		game.physics.arcade.collide(Denemy1,Dyellow1);
		game.physics.arcade.collide(Denemy1,Dyellow2);
		game.physics.arcade.collide(Denemy2,Dyellow1);
		game.physics.arcade.collide(Denemy2,Dyellow2);
		game.physics.arcade.overlap(boatplayer,Denemy1,process.killPlayer);
		game.physics.arcade.overlap(boatplayer,Denemy2,process.killPlayer2);
		game.physics.arcade.overlap(Aenemy,Dyellow1,process.killEnemy);
		game.physics.arcade.overlap(Aenemy,Dyellow2,process.killEnemy2);
		game.physics.arcade.overlap(yellow,Aenemy,process.GG);
		game.physics.arcade.overlap(black,boatplayer,process.youWin);

		boatplayer.body.velocity.x = 0;
		boatplayer.body.velocity.y= 0;
		bg.tilePosition.x +=0.6

		game.physics.arcade.moveToObject(Denemy1,boatplayer,50);
		game.physics.arcade.moveToObject(Denemy2,boatplayer,50);
		game.physics.arcade.moveToObject(Aenemy,yellow,250);
		game.physics.arcade.moveToObject(Dyellow1,Aenemy,50);
		game.physics.arcade.moveToObject(Dyellow2,Aenemy,50);
	
    
		 if (left) {
		        boatplayer.body.velocity.x = -100;
		        boatplayer.rotation = 0;
		    }
		 else if(right){
		 		boatplayer.body.velocity.x = 100;
		        boatplayer.rotation = 3.12;
		 	}
		 else if(down){
		 		boatplayer.body.velocity.y = 100;
		        boatplayer.rotation = 4.68;
		 	}	 
		 else if(up){
		 		boatplayer.body.velocity.y = -100;
		        boatplayer.rotation = 1.6;
		 	}
		 	else{
		 			boatplayer.body.velocity.x = 0;
		boatplayer.body.velocity.y= 0;
		 	}
	
		
	},

		pause: function(){
        	this.game.paused = true;
        	var pausedText = this.add.text((w/2)-130, 300, "         Game Paused.\nTap anywhere to continue.",{font:'24px Ar Christy', stroke: 'skyblue'}, this._fontStyle);
        	this.input.onDown.add(function(){
            pausedText.destroy();
            this.game.paused = false;
        	}, this);
   	 	},
    	restart: function(){
    		game.state.start(game.state.current);
    		bgAudio.destroy();
    		winAudio.destroy();
    		loseAudio.destroy();
    		
		}
		
}