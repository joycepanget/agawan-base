var process = function() {
	"use strict";
	return {
/*		audio: function(audio,time) {
			setInterval (function() {
			bgAudio.play();
		},time)
		}
	},*/
		killPlayer: function(boatplayer,Denemy1) {
			boatplayer.kill();
			yellow.kill();
			Dyellow2.kill();
			Dyellow1.kill();
		/*	game._paused = true;*/
			bgAudio.destroy();
			loseAudio.play();
      	gameOverText.text = "GAME OVER!";
			sabog = game.add.sprite(boatplayer.body.x,boatplayer.body.y,"sabog");

			sabog.animations.add("sabog",[1,2,3,4,5,6,7,8,9,10,11],5,true);

			sabog.animations.play("sabog");
	
			

		},
		killPlayer2: function(boatplayer,Denemy2) {
			boatplayer.kill();
			yellow.kill();
Dyellow2.kill();
			Dyellow1.kill();
		/*	game._paused = true;*/
			bgAudio.destroy();
			loseAudio.play();
		gameOverText.text = "GAME OVER!";
			sabog = game.add.sprite(boatplayer.body.x,boatplayer.body.y,"sabog");
			sabog.animations.add("sabog",[1,2,3,4,5,6,7,8,9,10,11],5,true);
			sabog.animations.play("sabog");
			

		},
		killEnemy: function(Aenemy,Dyellow1) {
			Aenemy.kill();
		/*	game._paused = true;*/
			
      
			sabog = game.add.sprite(Aenemy.body.x,Aenemy.body.y,"sabog");
			sabog.animations.add("sabog",[1,2,3,4,5,6,7,8,9,10,11],5,true);
			sabog.animations.play("sabog");
			

		},
		killEnemy2: function(Aenemy,Dyellow2) {
			Aenemy.kill();
		/*	game._paused = true;*/
			
      
			sabog = game.add.sprite(Aenemy.body.x,Aenemy.body.y,"sabog");
			sabog.animations.add("sabog",[1,2,3,4,5,6,7,8,9,10,11],5,true);
			sabog.animations.play("sabog");
			

		},
		GG: function(yellow,Aenemy) {
			yellow.kill();
			boatplayer.kill();
			Dyellow2.kill();
			Dyellow1.kill();
			bgAudio.destroy();
     pauseButton.destroy();
    	loseAudio.play();
      	gameOverText.text = "GAME OVER!";
      	
			sabog = game.add.sprite(yellow.body.x,yellow.body.y,"sabog");
			sabog.animations.add("sabog",[1,2,3,4,5,6,7,8,9,10,11],5,true);
			sabog.animations.play("sabog");
			

		},
		youWin: function(black,boatplayer) {
			black.kill();
			Denemy1.kill();
			Denemy2.kill();
			bgAudio.destroy();
		
			
    pauseButton.destroy();
    	winAudio.play();
      	gameOverText.text = "YOU WIN!";
			sabog = game.add.sprite(black.body.x,black.body.y,"sabog");
			
			sabog.animations.add("sabog",[1,2,3,4,5,6,7,8,9,10,11],5,true);
			sabog.animations.play("sabog");
	


		}
		
	}
}();	